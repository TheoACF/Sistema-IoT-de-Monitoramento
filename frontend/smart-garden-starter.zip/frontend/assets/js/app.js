// Config: altere se a API estiver em domínio separado (ex.: https://seu-api.vercel.app)
const API_BASE = "";

// util para compor URL
const api = (p) => (API_BASE ? API_BASE : "") + p;

async function loadStatus(){
  try{
    const r = await fetch(api("/api/status"));
    const j = await r.json();
    const dot = document.getElementById("connDot");
    const txt = document.getElementById("connText");
    if(j.online){ dot.className = "dot online"; txt.textContent = "Online"; }
    else { dot.className = "dot offline"; txt.textContent = "Offline"; }
    document.getElementById("deviceOnline").textContent = j.online ? "Online" : "Offline";
    document.getElementById("lastSeen").textContent = j.lastSeen ? new Date(j.lastSeen).toLocaleString() : "—";
    if(j.latest){
      document.getElementById("tempValue").textContent = Number(j.latest.temp).toFixed(1);
      document.getElementById("humValue").textContent = Number(j.latest.umid).toFixed(0);
      document.getElementById("tempStatus").textContent = j.latest.temp > j.limites.temp ? "Acima do limite" : "Normal";
      document.getElementById("humStatus").textContent = j.latest.umid < j.limites.umid ? "Baixa" : "Normal";
      if(j.latest.error){ dot.className = "dot warn"; txt.textContent = "Sensor com falha"; }
    }
  }catch(e){
    const dot = document.getElementById("connDot");
    const txt = document.getElementById("connText");
    dot.className = "dot offline";
    txt.textContent = "Erro ao conectar";
  }
}

async function loadHistory(){
  try{
    const r = await fetch(api("/api/history?limit=20"));
    const j = await r.json();
    const tbody = document.getElementById("tbody");
    tbody.innerHTML = "";
    (j.series || []).forEach(row=>{
      const tr = document.createElement("tr");
      const dt = new Date(row.ts).toLocaleString();
      tr.innerHTML = `<td>${dt}</td><td>${Number(row.temp).toFixed(1)}</td><td>${Number(row.umid).toFixed(0)}</td><td>${row.error? "sim":"não"}</td>`;
      tbody.appendChild(tr);
    });
  }catch(e){
    console.error(e);
  }
}

async function exportCSV(){
  const r = await fetch(api("/api/history?format=csv"));
  const txt = await r.text();
  const blob = new Blob([txt], {type:"text/csv;charset=utf-8;"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "historico.csv";
  a.click();
  URL.revokeObjectURL(url);
}

document.getElementById("btnExport").addEventListener("click", exportCSV);

loadStatus();
loadHistory();
setInterval(loadStatus, 10000);
setInterval(loadHistory, 15000);

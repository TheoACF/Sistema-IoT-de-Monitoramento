# Smart Garden IoT – Monorepo (Frontend / API / Firmware)

Estrutura:
```
/frontend   -> site estático (HTML/CSS/JS) que consome a API
/api        -> funções Serverless (Vercel) – ingest, history, status, config, alerts
/firmware   -> código Arduino para ESP-01 (ESP8266 + DHT22)
/public     -> config.json (dev local) e, opcionalmente, dados.txt (somente dev)
```

## 1) Como usar este pacote
1. Crie um repositório no GitHub (vazio) e **faça upload de TODO este conteúdo** (ou `git init` + `git add .` + `git commit -m "starter"` + `git push origin main`).
2. Na **Vercel**, crie **dois projetos** a partir do MESMO repositório:
   - Projeto **Frontend** -> Root Directory: `frontend`
   - Projeto **API**      -> Root Directory: `api`
3. No projeto **API** da Vercel, configure variáveis de ambiente (opcional, para usar Firebase em produção):
   - `FIREBASE_DB_URL` – ex.: `https://SEU_DB.firebaseio.com`
   - `FIREBASE_SERVICE_ACCOUNT` – conteúdo **base64** do JSON da conta de serviço
   - `INGEST_KEY` – (opcional) segredo para autenticar o ESP
4. Faça deploy. Você terá duas URLs: ex. `https://seu-frontend.vercel.app` e `https://sua-api.vercel.app`.

> **Arquivo** `/api/package.json` já inclui `firebase-admin`. A Vercel instalará automaticamente.

## 2) Endpoints disponíveis
- `GET/POST /api/ingest`  – recebe dados do ESP (`temp`, `umid`, `error=true|false`, `key`)
- `GET /api/history?limit=60&format=csv` – últimas leituras (JSON ou CSV)
- `GET /api/status` – online/offline + última leitura + limites
- `GET /api/config` – lê config (dev: `public/config.json`, prod: Firebase)
- `POST /api/config` – salva config
- `GET /api/alerts` – avalia limites e status; retorna lista de alertas

> Em **dev local**, os dados são gravados/ lidos de `public/dados.txt` (JSONL). Em **produção**, use Firebase via env vars.

## 3) Configurar o Frontend
- Arquivo: `frontend/index.html`
- Script: `frontend/assets/js/app.js`. Se a API estiver em outro domínio, edite `API_BASE`.
- Botão **Exportar CSV** consome `/api/history?format=csv`.

## 4) Firmware (ESP-01 + DHT22)
- Arquivo: `firmware/esp01_dht22.ino`
- Ajuste:
  - `WIFI_SSID`, `WIFI_PASS`
  - `API_HOST` (ex.: `sua-api.vercel.app`)
  - `INGEST_KEY` (se configurado na Vercel)
- Envio: **GET** para `/api/ingest` (HTTPS com `setInsecure()` para protótipo)
- Lê a cada 1 min; envia a cada 10 min (ou envia imediatamente se o sensor falhar).

## 5) Fluxo de teste
1. Rode local (opcional):
   - API: `cd api && npx vercel dev` (ou `node` não é necessário)
   - Frontend: abra `frontend/index.html` no navegador (ou sirva com `npx serve`)
2. No Serial Monitor do ESP, verifique conexão WiFi e respostas HTTP.
3. Acesse `.../api/status` e `.../api/history` para ver JSON no navegador.
4. Abra o site (frontend) e confira cartões e tabela atualizando.

## Observações importantes
- O **filesystem da Vercel é somente leitura**; por isso, **em produção use Firebase**.
- `FIREBASE_SERVICE_ACCOUNT` deve ser o **JSON completo em base64** do arquivo de conta de serviço.
  - Ex.: `base64 serviceAccountKey.json` -> cole na env var.
- Este starter é mínimo. Você pode evoluir para gráficos, filtros de data, authenticação etc.
